<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'jelastic-5565475' );

/** MySQL database password */
define( 'DB_PASSWORD', 'uMHaEYewT11DWx89Ug40' );

/** MySQL hostname */
define( 'DB_HOST', 'DB_1' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'BHr`%nodqvyTY o0tGy?jhnvk`$tZ{%NI:M8xZQQ,1MZ@|=upfk|EX)Q!UHyU+H}' );
define( 'SECURE_AUTH_KEY',   'ktb8u9J%?=JwCetV]mNvtWZ7%mWt2EY:(N34Ohf%yfts$HP7v>ud&th.pKBN(n?&' );
define( 'LOGGED_IN_KEY',     's;-<<PY+~rhiglyt.*rkRW3Km6,yR:agBSCm:2h}2.7Q<afVQJ,iNT#3=|gk=BE~' );
define( 'NONCE_KEY',         'F&ri1 N<yV$S$Yji6j5(#JFxX=E816$D1cCF*Er)a%IV5>sr*1e>CU+!w;`H,<*4' );
define( 'AUTH_SALT',         'k$FMkI&;&up8n1ETHw}w`WMp2L^phrL,mr1wiV.q)(:)|5G[Oy7m2whMb~Ius)CJ' );
define( 'SECURE_AUTH_SALT',  'nK~(^1!X.HMumuu&;KWy2Ko]a|,>V!?3[gr>adGNfzEag|iEBjS=7:H8Ov rU}9,' );
define( 'LOGGED_IN_SALT',    'M.ipC1UX]~;$&O{0vInH)I7rk9e),`Z#:(bs: 8^VZ8 Ak@M%yY3DLg^%!0E:kt:' );
define( 'NONCE_SALT',        '2,41!v./{&hpG~rM38Ua^_&SeWs=4H|?kVvNnar6!^gH-KEB9u++PJMKvCP653](' );
define( 'WP_CACHE_KEY_SALT', 'eYA+t$ $)?&MK:cw849`=cp1Hk<raChs<H=:041]OwBO?qM!g$|a3}y*Nyf}jUb#' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-jelastic.php';
require_once ABSPATH . 'wp-settings.php';
